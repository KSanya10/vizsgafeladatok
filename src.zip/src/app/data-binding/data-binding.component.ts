import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-data-binding',
  templateUrl: './data-binding.component.html',
  styleUrls: ['./data-binding.component.css']
})
export class DataBindingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

AoldalErtek:number=0;
BoldalErtek:number=0;
Eredmenyek:string[]=[];


EredmenyMentes():void{
  this.Eredmenyek.push(`Az ${this.AoldalErtek} és ${this.BoldalErtek} oldalú téglalap kerülete ${(this.AoldalErtek+this.BoldalErtek)*2} ; területe: ${this.AoldalErtek*this.BoldalErtek}`)
}
}
