function Rng(alsoHatar, felsoHatar) {
    var randomSzamAdottIntervallumban = Math.round(Math.random() * (felsoHatar - alsoHatar)) + alsoHatar;
    return randomSzamAdottIntervallumban;
}
function TombGenerator(meret, alsoHatar, felsoHatar) {
    var tomb = [];
    for (var i = 0; i < meret; i++) {
        var randomSzamAdottIntervallumban = Math.round(Math.random() * (felsoHatar - alsoHatar)) + alsoHatar;
        tomb.push(randomSzamAdottIntervallumban);
    }
    return tomb;
}
