function Rng(alsoHatar:number, felsoHatar:number):number{
    let randomSzamAdottIntervallumban:number=Math.round(Math.random()*(felsoHatar-alsoHatar))+alsoHatar;
    return randomSzamAdottIntervallumban
}

function TombGenerator(meret:number, alsoHatar:number, felsoHatar:number):number[]{
    let tomb:number[]=[];
    for(let i=0;i<meret; i++){
        let randomSzamAdottIntervallumban:number=Math.round(Math.random()*(felsoHatar-alsoHatar))+alsoHatar;
        tomb.push(randomSzamAdottIntervallumban)
    }
return tomb
}

